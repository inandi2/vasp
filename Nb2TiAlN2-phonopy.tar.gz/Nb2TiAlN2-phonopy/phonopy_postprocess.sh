
for dir in ./*/2_phonopy/
do cd $dir || continue
echo $pwd
echo $dir
rm band*
rm *jpg

cat >>band.conf<< eof
-----band.conf----G-X-K-G-L
DIM = 2 1 1
PRIMITIVE_AXIS = 1.0 0.0 0.0  0.0 1.0 0.0  0.0 0.0 1.0
BAND = 0.0 0.0 0.0  0.0 0.5 0.5  0.375 0.75 0.375  0.0 0.0 0.0  0.5 0.5 0.5
eof

#FORCE_CONSTANTS = READ

cat >>band1.conf<< eof
ATOM_NAME = Ti Sc N O
DIM =  2 1 1
BAND = 0.5 0.5 0.5  0.0 0.0 0.0  0.5 0.5 0.0  0.0 0.5 0.0
eof


phonopy -f disp-{001..042}/vasprun.xml

phonopy -p band1.conf -s


convert -density 400  band.pdf -quality 200 band.jpg



cd ../..

done

mv Nb2ScN2O2/2_phonopy/band.jpg Nb2ScN2O2.jpg
mv Nb2YN2O2/2_phonopy/band.jpg Nb2YN2O2.jpg
mv Nb2TiN2O2/2_phonopy/band.jpg Nb2TiN2O2.jpg
mv Nb2ZrN2O2/2_phonopy/band.jpg Nb2ZrN2O2.jpg
mv Ta2ScN2O2/2_phonopy/band.jpg Ta2ScN2O2.jpg
mv Ti2ScN2O2/2_phonopy/band.jpg Ti2ScN2O2.jpg
mv V2TiN2O2/2_phonopy/band.jpg V2TiN2O2.jpg
mv Zr2YN2O2/2_phonopy/band.jpg Zr2YN2O2.jpg


