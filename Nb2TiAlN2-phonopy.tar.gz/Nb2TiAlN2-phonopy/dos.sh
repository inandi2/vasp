cd -P . 

#for dir in ./*/1_relax/
#for dir in ./*/2_scf/
#for dir in ./*/3_dos/
for dir in ./*/3_dos_1/
#for dir in ./*/
do cd $dir || continue
	echo $pwd
	echo $dir
	rm dos* pdos*
	cp ../../plotDOS.py .
	cp ../../plotPDOS.py .
	python3 plotDOS.py
	python3 plotPDOS.py
#	rm *
#	cp CONTCAR POSCAR
#	cp ../INCAR .
#rm CHG       EIGENVAL     OSZICAR  PCDAT         REPORT       WAVECAR 
#rm CHGCAR  DOSCAR   IBZKPT    OUTCAR       PROCAR     vasprun.xml  XDATCAR 
#chmod 777 *
#mkdir 1_relax 2_scf 3_dos 4_bs

# echo 1_relax | xargs -r -n1 cp ../INCAR KPOINTS POSCAR POTCAR
#cp ../../INCAR_relax .
#cp ../KPOINTS .
#cp ../POSCAR .
#cp ../POTCAR .
#mv INCAR_relax INCAR
#mv CONTCAR POSCAR

## 2_scf
#cp ../../INCAR_scf .
#cp ../1_relax/CONTCAR .
#cp ../1_relax/KPOINTS .
#cp ../1_relax/POTCAR .
#mv INCAR_scf INCAR
#mv CONTCAR POSCAR

## 3_dos
#cp ../../INCAR_dos .
#cp ../../KPOINTS_dos .
#cp ../1_relax/CONTCAR .
#cp ../2_scf/CHGCAR .
#cp ../2_scf/POTCAR .

#mv INCAR_dos INCAR
#mv KPOINTS_dos KPOINTS
#mv CONTCAR POSCAR


#chmod 777 *

#mpirun -np 4 vasp_std
	cd ../../
done
