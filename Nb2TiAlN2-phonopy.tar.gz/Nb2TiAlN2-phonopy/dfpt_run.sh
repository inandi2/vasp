
for dir in ./*/
do cd $dir || continue
rm -r dfpt
mkdir dfpt
	cd dfpt
	echo $dir
	echo $pwd
 	cp ../1_relax/CONTCAR .
 	cp ../1_relax/POTCAR .
 	cp ../../KPOINTS_phonopy .
	cp ../../INCAR_phonopy .
	cp CONTCAR POSCAR
	cp INCAR_phonopy INCAR
	cp KPOINTS_phonopy KPOINTS
	phonopy -d --dim="1 1 1" -c POSCAR
	cp SPOSCAR POSCAR
	mpirun -np 6 vasp_std
	cd ..
cd ..
done
