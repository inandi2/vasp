from pymatgen.io.vasp import Vasprun
from pymatgen.electronic_structure.plotter import DosPlotter

v=Vasprun('./vasprun.xml')
tdos = v.tdos
plotter = DosPlotter()
plotter.add_dos('Total DOS', tdos)
#plotter.show(xlim=[-20, 20],ylim=[-15, 15])

plotter.save_plot("dos.png", img_format="png", xlim=[-20, 20], ylim=[-15, 15])
plotter.save_plot("dos.pdf", img_format="pdf", xlim=[-20, 20], ylim=[-15, 15])

