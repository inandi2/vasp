cd -P . 

for dir in ./*/
do cd $dir || continue
	mkdir 3_dos_1
	cd ..
done
