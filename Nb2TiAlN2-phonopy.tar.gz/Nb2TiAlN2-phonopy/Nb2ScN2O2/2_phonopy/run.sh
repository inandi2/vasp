cp ../1_relax/CONTCAR .
cp ../1_relax/POTCAR .
cp CONTCAR POSCAR

cat >INCAR<<EOF
SYSTEM  = MXENE
ALGO = Normal
EDIFF   = 1E-8
ENCUT = 520
IBRION = -1
ISMEAR = 0
LREAL = .False.
LWAVE = .False
PREC = Accurate
SIGMA = 0.01
NSW   = 0
ISYM=0
NELM = 100
LCHARG = .FALSE.

#LSCALAPACK = .False.
#ICHARG = 0
#LDAU = True
#LDAUJ = 0 0 0 0
#LDAUL = 2 2 0 0
#LDAUPRINT = 1
#LDAUTYPE = 2
#LDAUU = 4 4 0 0
EOF
cat > KPOINTS<<EOF
KPOINTS
0
Gamma
6 6 6
0 0 0
EOF

#<!skip>
rm -r disp*
rm POSCAR-*
phonopy -d --dim="2 1 1"
for i in {001..042..1}
do mkdir disp-$i
	cd disp-$i
	cp ../POSCAR-$i .
        cp POSCAR-$i POSCAR
	cp ../INCAR .
	cp ../KPOINTS .
	cp ../POTCAR . 
	echo $pwd
	mpirun -np 6 vasp_std
	cd ..
done

