import numpy as np
from matplotlib import pyplot as plt
import matplotlib
import matplotlib.pyplot as plt
import pymatgen

from pymatgen.io.vasp import Vasprun
from pymatgen.electronic_structure.plotter import DosPlotter

v=Vasprun('./vasprun.xml')
cdos=v.complete_dos
element_dos = cdos.get_element_dos()
plotter = DosPlotter()
plotter.add_dos_dict(element_dos)
#plotter.save_plot("foo.pdf", transparent = True)

plotter.save_plot("pdos.png", img_format="png", xlim=[-20, 20], ylim=[-8, 8])
plotter.save_plot("pdos.pdf", img_format="pdf", xlim=[-20, 20], ylim=[-8, 8])




#plotter.show(xlim=[-20, 20], ylim = [-8, 8])
#save_plot(dos, img_format='eps', ylim=None, zero_to_efermi=True, smooth=False)
#plt.savefig('foo.png')
#plt.savefig('foo.pdf')
#plt = self.get_plot(ylim=None, zero_to_efermi=zero_to_efermi, smooth=smooth)
#plt.savefig(foo, format="png")
#plt.close()
