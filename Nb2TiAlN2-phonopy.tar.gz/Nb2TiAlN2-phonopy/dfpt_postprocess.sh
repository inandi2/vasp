
for dir in ./*/dfpt/
do cd $dir || continue
echo $pwd
echo $dir
rm band.conf

cat >>band.conf<< eof
-----band.conf----G-X-K-G-L
DIM = 1 1 1
PRIMITIVE_AXIS = 1.0 0.0 0.0  0.0 1.0 0.0  0.0 0.0 1.0
BAND = 0.0 0.0 0.0  0.0 0.5 0.5  0.375 0.75 0.375  0.0 0.0 0.0  0.5 0.5 0.5
FORCE_CONSTANTS = READ
eof
phonopy --fc vasprun.xml
phonopy --dim="1 1 1" -c POSCAR band.conf
phonopy -p band.conf
cd ../..
done

