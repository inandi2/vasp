#vasp_phonopy_run
#------------------------------------------------------------------------------
#■ Youtube動画：
#基本的な使い方： https://www.youtube.com/watch?v=uQ2OsXZbhMY
#group velocity and thermal displacements: https://www.youtube.com/watch?v=IT5KzcnD_eI
------------------------------------------------------------------------------
#■ setting
#1. chmod +x vasp_phonopy_run
#2. gedit vasp_phonopy_run
#change
#------
#set vasp_adress = $HOME'/vasp/vasp.5.4.1/bin/vasp_std'
#set vasp_adress = $HOME'/vasp/vasp.5.3/vasp'
------
#3. gedit vasp_phonopy_run
#If you get libraries form Ubuntu Software center, I reccommend below,
#------before
#set __mpirun__ = "mpirun"
#if you get libraries form Ubuntu Software center, I reccommend below,
#set __mpirun__ = "mpirun.openmpi"
#------
#------after
#set __mpirun__ = "mpirun"
#if you get libraries form Ubuntu Software center, I reccommend below,
#set __mpirun__ = "mpirun.openmpi"
------
------------------------------------------------------------------------------
#■ Usage
#0. calculate optimized structure (for example, vasp_run)
#1. vasp_phonopy_run
#2. vasp_phonopy_run

#recalculation
#1. mv disp.yaml disp.yaml_backup
#  if you want to need new setting
#mv band.conf band.conf_backup
#mv mesh.conf mesh.conf_backup
#mv pdos.conf pdos.conf_backup
#2. vasp_phonopy_run

#setting band.conf
#Youtube: https://www.youtube.com/watch?v=VvHgjCOoKhM
#------------------------------------------------------------------------------
#■ Output data
#band structure:  band_data.txt
#pdos and tdos: partial_dos.dat
#pdos element data: pdos_data.txt
------------------------------------------------------------------------------
#■ vasp_phonopy_run
----------
#! /bin/csh -f
# VASP run command
#
# user settting
#set vasp_adress = $HOME'/vasp/vasp.5.4.1/bin/vasp_std'
#set vasp_adress = $HOME'/vasp/vasp.5.3/vasp'
#set __mpirun__ = "mpirun"
#if you get libraries form Ubuntu Software center, I reccommend below,
#set __mpirun__ = "mpirun.openmpi"
#set file    = `pwd`
#set file    = $file:t
# Automatically setting
#set num_core = `grep 'core id' /proc/cpuinfo | sort -u | wc -l`
#setenv OMP_NUM_THREADS 1
#
# DFPT
#if ( -f disp.yaml ) then
#  echo "already disp.yaml"
#else
#  echo "   PREC = Accurate" > INCAR
#  echo "#  ENCUT = 500    " >> INCAR
#  echo " IBRION = 8       " >> INCAR
#  echo "  EDIFF = 1.0e-08 " >> INCAR
#  echo "  IALGO = 38      " >> INCAR
#  echo " ISMEAR = 0; SIGMA = 0.1" >> INCAR
#  echo "  LREAL = .FALSE. " >> INCAR
#  echo "ADDGRID = .TRUE.  " >> INCAR
#  echo "  LWAVE = .FALSE. " >> INCAR
#  echo " LCHARG = .FALSE. " >> INCAR
#  mv KPOINTS KPOINTS_
#  cp POSCAR POSCAR_backup
#  mv POSCAR POSCAR-unitcell
#  phonopy -d --dim="2 2 2" -c POSCAR-unitcell
#  mv SPOSCAR POSCAR
#  ${__mpirun__} -np $num_core $vasp_adress
#  phonopy --fc vasprun.xml
#endif
#
# phonopy dos plot
if ( -f mesh.conf ) then
  echo "use mesh.conf"
else
  echo "automatically make mesh.conf file"
  echo "DIM = 2 2 2           " >  mesh.conf
  echo "MP = 16 16 16         " >> mesh.conf
  echo "FORCE_CONSTANTS = READ" >> mesh.conf
  echo "TPROP = .TRUE.        " >> mesh.conf
  echo "TMIN  = 0             " >> mesh.conf
  echo "TMAX  = 2000          " >> mesh.conf
  echo "TSTEP = 10            " >> mesh.conf
  #echo "DOS_RANGE = 0 40 0.1  " >> mesh.conf
  #echo "SIGMA = 0.1           " >> mesh.conf
  #echo "DEBYE_MODEL = .TRUE.  " >> mesh.conf
  #echo "MOMENT = .TRUE.       " >> mesh.conf
  #echo "MOMENT_ORDER = 3      " >> mesh.conf
endif
#phonopy --dim="2 2 2" -c POSCAR-unitcell -p mesh.conf &
phonopy --dim="2 2 2" -c POSCAR-unitcell -t -p mesh.conf -s
phonopy --dim="2 2 2" -c POSCAR-unitcell -t -p mesh.conf &
#
# phonopy pdos plot
if ( -f pdos.conf ) then
  echo "use pdos.conf"
else
  # POSCAR-unitcell
  sed -n 6p POSCAR-unitcell
  set no_list=`sed -n 7p POSCAR-unitcell`
  echo ${no_list}
  echo "PDOS = " > pdos_temp1
  set n = 1
  foreach no ( ${no_list} )
    set npc = 1
    while (${npc} <= ${no})
      set pdos_temp = `cat pdos_temp1`
      echo "${pdos_temp} ${n}" > pdos_temp1
      @ n = ${n} + 1
      @ npc = ${npc} + 1
    end
    set pdos_temp = `cat pdos_temp1`
    echo "${pdos_temp}," > pdos_temp1
  end
  # tdos
  set n = 1
  foreach no ( ${no_list} )
    set npc = 1
    while (${npc} <= ${no})
      set pdos_temp = `cat pdos_temp1`
      echo "${pdos_temp} ${n}" > pdos_temp1
      @ n = ${n} + 1
      @ npc = ${npc} + 1
    end
    set pdos_temp = `cat pdos_temp1`
    echo "${pdos_temp}" > pdos_temp1
  end
  set pdos_temp = `cat pdos_temp1`
  set pdos_temp2 = `sed -n 6p POSCAR-unitcell`
  echo "PDOS = "${pdos_temp2}" TDOS" >  pdos_data.txt
  echo "${pdos_temp}"              >> pdos_data.txt
  rm -f -r pdos_temp1
  #
  echo "automatically make pdos.conf file"
  echo "DIM = 2 2 2              " >  pdos.conf
  echo "MP = 16 16 16            " >> pdos.conf
  echo "${pdos_temp}"              >> pdos.conf
  echo "FORCE_CONSTANTS = READ   " >> pdos.conf
  #echo "DOS_RANGE = 0 40 0.1     " >> pdos.conf
  #echo "SIGMA = 0.1              " >> pdos.conf
  #echo "DEBYE_MODEL = .TRUE.     " >> pdos.conf
  #echo "MOMENT = .TRUE.          " >> pdos.conf
  #echo "MOMENT_ORDER = 3         " >> pdos.conf
endif
# THz
#phonopy --dim="2 2 2" -c POSCAR-unitcell -p pdos.conf -v
# meV
phonopy --dim="2 2 2" -c POSCAR-unitcell -p pdos.conf --factor 64.6541363414 -v --irreps="0 0 0" > pdos.txt
phonopy --dim="2 2 2" -c POSCAR-unitcell -p pdos.conf --factor 64.6541363414 &
# pdosplot
sed -n 2p pdos_data.txt > pdosplot_data.txt
set pdos_data = `sed -e 's/PDOS = //g' pdosplot_data.txt`
rm -f -r pdosplot_data.txt
cp "$HOME/phonopy"*"/scripts/pdosplot" ./
pdosplot  --xlabel="Energy (meV)" --ylabel="Partial density of states (States/meV)" --title="${file}" --factor 4.13566733 --indices="${pdos_data}" --output="partial_dos.tiff"
#
# phonopy band plot
if ( -f band.conf ) then
  echo "use band.conf"
else
  # FCC
  echo "automatically make band.conf file"
  echo "DIM = 2 2 2           " > band.conf
  echo "BAND = 0.0 0.0 0.0  0.0 0.5 0.5  0.375 0.75 0.375  0.0 0.0 0.0  0.5 0.5 0.5" >> band.conf
  echo "FORCE_CONSTANTS = READ" >> band.conf
  echo 'BAND_LABELS = $\Gamma$ X K $\Gamma$ L' >> band.conf
  echo "BAND_POINTS = 51" >> band.conf
  echo "GROUP_VELOCITY = .TRUE." >> band.conf
  echo "GV_DELTA_Q = 0.01" >> band.conf
  #echo "BAND_CONNECTION = .TRUE." >> band.conf
  #
  #----- WIEN2k setting -----
  # FCC, W - L - LAMBDA - G - DELTA - X - Z - W - K, Primitive Brillouin Zone (Please check result)
  echo "DIM = 2 2 2           "   > band.conf_fcc
  echo "BAND = 0.25 0.5 0.75  0.5 0.5 0.5  0.25 0.25 0.25  0.0 0.0 0.0  0.0 0.25 0.25  0.0 0.5 0.5  0.125 0.5 0.625  0.25 0.5 0.75  0.375 0.375 0.75" >> band.conf_fcc
  echo "FORCE_CONSTANTS = READ"  >> band.conf_fcc
  echo 'BAND_LABELS = W L $\Lambda$ $\Gamma$ $\Delta$ X Z W K' >> band.conf_fcc
  echo "BAND_POINTS = 51"        >> band.conf_fcc
  echo "GROUP_VELOCITY = .TRUE." >> band.conf_fcc
  echo "GV_DELTA_Q = 0.01"       >> band.conf_fcc
  # BCC, G - DELTA - H - N - SIGMA - G - LAMBDA - P, Primitive Brillouin Zone (Please check result)
  echo "DIM = 2 2 2           "   > band.conf_bcc
  echo "BAND = 0.0 0.0 0.0  0.25 0.25 -0.25  0.5 0.5 -0.5  0.0 0.5 0.0  0.0 0.25 0.0  0.0 0.0 0.0  0.125 0.125 0.125  0.25 0.25 0.25" >> band.conf_bcc
  echo "FORCE_CONSTANTS = READ"  >> band.conf_bcc
  echo 'BAND_LABELS = $\Gamma$ $\Delta$ H N $\Sigma$ $\Gamma$ $\Lambda$ P' >> band.conf_bcc
  echo "BAND_POINTS = 51"        >> band.conf_bcc
  echo "GROUP_VELOCITY = .TRUE." >> band.conf_bcc
  echo "GV_DELTA_Q = 0.01"       >> band.conf_bcc
  # HCP, G - SIGMA - M - K - LAMBDA - G - DELTA - A, Primitive Brillouin Zone (Please check result)
  echo "DIM = 2 2 2           "   > band.conf_hcp
  echo "BAND = 0.0 0.0 0.0  0.25 0.0 0.0  0.5 0.0 0.0  1/3 1/3 0.0  1/6 1/6 0.0  0.0 0.0 0.0  0.0 0.0 0.25  0.0 0.0 0.5" >> band.conf_hcp
  echo "FORCE_CONSTANTS = READ"  >> band.conf_hcp
  echo 'BAND_LABELS = $\Gamma$ $\Sigma$ M K $\Lambda$ $\Gamma$  $\Delta$ A' >> band.conf_hcp
  echo "BAND_POINTS = 51"        >> band.conf_hcp
  echo "GROUP_VELOCITY = .TRUE." >> band.conf_hcp
  echo "GV_DELTA_Q = 0.01"       >> band.conf_hcp
  # SC, R - LAMBDA - G - DELTA - X - Z - M - SIGMA - G, Primitive Brillouin Zone (Please check result)
  echo "DIM = 2 2 2           "   > band.conf_sc
  echo "BAND = 0.5 0.5 0.5  0.25 0.25 0.25  0.0 0.0 0.0  0.25 0.0 0.0  0.5 0.0 0.0  0.5 0.25 0.0  0.5 0.5 0.0  0.25 0.25 0.0  0.0 0.0 0.0" >> band.conf_sc
  echo "FORCE_CONSTANTS = READ"  >> band.conf_sc
  echo 'BAND_LABELS = R $\Lambda$ $\Gamma$ $\Delta$ X Z M $\Sigma$ $\Gamma$' >> band.conf_sc
  echo "BAND_POINTS = 51"        >> band.conf_sc
  echo "GROUP_VELOCITY = .TRUE." >> band.conf_sc
  echo "GV_DELTA_Q = 0.01"       >> band.conf_sc
  #----- WIEN2k setting -----
  #
  # detect symmetry
  # phonopy --symmetry -tolerance=some_distance > sym.dat
  phonopy --symmetry > sym.dat
  sed -n -e /space_group_type:/p sym.dat > out.txt
  awk '{print $2}' out.txt > out2.txt
  cut -c 1 out2.txt > band_path.conf
  rm -f -r out.txt
  rm -f -r out2.txt
  #
  # exchange band path file
  set bravais = `awk '{print $1}' band_path.conf`
  echo "bravais lattice:" ${bravais}
  switch( ${bravais} )
    case F :
      echo "set fcc band path"
      cp band.conf_fcc band.conf
      breaksw
    case B :
      echo "set bcc band path"
      cp band.conf_bcc band.conf
      breaksw
    case H :
      echo "set hcp band path"
      cp band.conf_hcp band.conf
      breaksw
    default :
      echo "set simple cubic band path"
      cp band.conf_sc band.conf
  endsw
endif
  #
phonopy --dim="2 2 2" -c POSCAR-unitcell band.conf --gv
cp "$HOME/phonopy"*"/scripts/bandplot" ./
# THz
#bandplot --xlabel="" --ylabel="Frequency (THz)" --title="${file}" --fmin=0 --fmax=12
#bandplot --xlabel="" --ylabel="Frequency (THz)" --title="${file}" --fmin=0 --fmax=12 --dos=partial_dos.dat &
# meV
bandplot --factor 4.13566733 --gnuplot > band_data.txt
#bandplot --xlabel="" --ylabel="Energy (meV)" --title="${file}" --fmin=-10 --fmax=50 --factor 4.13566733 --output="band_plot.tiff"
#bandplot --xlabel="" --ylabel="Energy (meV)" --title="${file}" --fmin=-10 --fmax=50 --dos=partial_dos.dat --factor 4.13566733 --output="band_pdos_plot.tiff"
bandplot --xlabel="" --ylabel="Energy (meV)" --title="${file}" --factor 4.13566733 --output="band_plot.tiff"
bandplot --xlabel="" --ylabel="Energy (meV)" --title="${file}" --dos=partial_dos.dat --factor 4.13566733 --output="band_pdos_plot.tiff"
bandplot --xlabel="" --ylabel="Energy (meV)" --title="${file}" --dos=partial_dos.dat --factor 4.13566733 &
#
# phonopy atomic displacements
echo "automatically make tdis.conf file"
echo "DIM = 2 2 2              " >  tdis.conf
echo "MP = 16 16 16            " >> tdis.conf
echo "FORCE_CONSTANTS = READ   " >> tdis.conf
echo "TDISPMAT = .TRUE.        " >> tdis.conf
# 300 K
phonopy --tdm tdis.conf --tdm_cif=300
#
if ( -d results ) then
  echo "use results folder"
else
  mkdir results
endif
cp pdos_data.txt       ./results/pdos_data.txt
cp pdos.txt            ./results/pdos.txt
cp band_data.txt       ./results/band_data.txt
cp partial_dos.dat     ./results/partial_dos.dat
cp tdispmat.cif        ./results/tdispmat.cif
cp band.yaml           ./results/group_velocity.txt
#
if ( -d graph ) then
  echo "use graph folder"
else
  mkdir graph
endif
cp partial_dos.tiff    ./graph/partial_dos.tiff
cp band_pdos_plot.tiff ./graph/band_pdos_plot.tiff
cp band_plot.tiff      ./graph/band_plot.tiff
cp tdispmat.cif        ./graph/tdispmat.cif
#
mv POSCAR_backup POSCAR
#
-----
------------------------------------------------------------------------------
