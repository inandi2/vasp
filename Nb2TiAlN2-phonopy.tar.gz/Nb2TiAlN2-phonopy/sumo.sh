sumo-dosplot --width 15 --height 8 --xmin -8 --xmax 10 --columns 2 --format png
