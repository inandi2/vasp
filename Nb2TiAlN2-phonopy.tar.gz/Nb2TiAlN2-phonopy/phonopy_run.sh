for dir in ./*/
do cd $dir || continue
	echo $dir
	if [ -d "2_phonopy" ]; then
 	 echo "folder 2_phonopy exist"
	else
		echo "No folder"
		mkdir 2_phonopy
		cd 2_phonopy
		cp ../../Nb2ScN2O2/2_phonopy/run.sh .
		chmod 775 *
		./run.sh
		phonopy -f disp-{001..042}/vasprun.xml
		cd ..
	fi
cd ..
done


